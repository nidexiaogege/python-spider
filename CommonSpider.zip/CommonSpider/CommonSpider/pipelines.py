# -*- coding: utf-8 -*-

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://doc.scrapy.org/en/latest/topics/item-pipeline.html

import sqlite3

class CommonspiderPipeline(object):
    def __init__(self):
        self.conn = sqlite3.connect('job.db')
        self.cursor = self.conn.cursor()
        self.cursor.execute("create table IF NOT EXISTS jobs_in_beijing(id char(50) primary key , company char(50), job char(50), salary char(50), job_des text, job_addr char(100));")
        self.conn.commit()
    def process_item(self, item, spider):
        sql = "INSERT INTO jobs_in_beijing(id, company, job, salary, job_des, job_addr) VALUES ('{}','{}','{}','{}','{}','{}')".format(item['id'],item['company'],item['job'],item['salary'],item['job_des'],item['job_addr'])
        self.cursor.execute(sql)
        self.conn.commit()
        return item