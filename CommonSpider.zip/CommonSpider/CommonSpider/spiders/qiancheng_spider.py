# -*- coding: utf-8 -*-
import scrapy
import hashlib
from CommonSpider.items import CommonspiderItem
from scrapy import Request
class QianchengSpiderSpider(scrapy.Spider):
    name = 'qiancheng_spider'
    # allowed_domains = ['www.51job.com']
    start_urls = ['https://search.51job.com/list/010000,000000,0000,00,9,99,python,2,2.html?lang=c&stype=&postchannel=0000&workyear=99&cotype=99&degreefrom=99&jobterm=99&companysize=99&providesalary=99&lonlat=0%2C0&radius=-1&ord_field=0&confirmdate=9&fromType=&dibiaoid=0&address=&line=&specialarea=00&from=&welfare=']

    def parse(self, response):
        item = CommonspiderItem()
        md5 = hashlib.md5()
        if response.url.split('/')[2] == 'jobs.51job.com':
            try:
                md5.update(response.url.encode('utf8'))
                gongsi = response.xpath('//div[@class="tHeader tHjob"]/div[@class="in"]/'
                                        'div[@class="cn"]/p[@class="cname"]/a[@class="catn"]/text()').extract()[0].split('\t')[5]
                zhiwei = response.xpath('//div[@class="tHeader tHjob"]/div[@class="in"]/'
                                        'div[@class="cn"]/h1/text()').extract()[0].split('\t')[4]
                xinzi = response.xpath('//div[@class="tHeader tHjob"]/div[@class="in"]/'
                                       'div[@class="cn"]/strong/text()').extract()[0]
            except Exception as e:
                print(e)
            else:
                print('-------------华丽的分割线----------')
                item['id'] = md5.hexdigest()
                item['company'] = gongsi
                item['job'] = zhiwei
                item['salary'] = xinzi
                job_descriptor = response.xpath('/html/body/div[3]/div[2]/div[3]/div[1]/div/p/text()').extract()
                job_result = ''
                for job_str in job_descriptor:
                    job_result += job_str
                print(job_result)
                item['job_des'] = job_result
                add_str = ''
                job_addr = response.xpath('/html/body/div[3]/div[2]/div[3]/div[2]/div/p/text()').extract()
                for i in job_addr:
                    add_str +=i
                item['job_addr'] = add_str.replace('\n','').replace('\t','')
                yield item
        all_hrefs = response.xpath('//a[@target="_blank" and @onmousedown=""]/@href').extract()
        last_url =response.xpath( '//*[@id="resultList"]/div[@class="dw_page"]/div[@class="p_box"]/div/div/ul/li[last()]/a/@href').extract()
        if last_url:
            all_hrefs.append(last_url[0])

        for url_str in all_hrefs:
            if url_str.find('0') > 0:
                yield Request(url=url_str, callback=self.parse)
