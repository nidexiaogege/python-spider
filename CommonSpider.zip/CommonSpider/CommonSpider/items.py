# -*- coding: utf-8 -*-

# Define here the models for your scraped items
#
# See documentation in:
# https://doc.scrapy.org/en/latest/topics/items.html

import scrapy


class CommonspiderItem(scrapy.Item):
    # define the fields for your item here like:
    # name = scrapy.Field()
    id = scrapy.Field()
    company = scrapy.Field()
    job = scrapy.Field()
    salary = scrapy.Field()
    job_des = scrapy.Field()
    job_addr = scrapy.Field()
